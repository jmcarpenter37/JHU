public class PrintJava {
    public static void main(String args[])
    {
        System.out.println("    J    A       V     V      A\n" +
                           "    J   A  A      V   V      A A\n" +
                           "J   J  AAAAAA      V V      AAAAA\n" +
                           " J J  A      A      V      A     A");
    }
}
